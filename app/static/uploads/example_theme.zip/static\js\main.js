/**
 * Ana JavaScript Dosyası
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('Örnek tema yüklendi!');
    
    // Mobil menü
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
        });
    }
    
    // Sayfa animasyonları
    const animatedElements = document.querySelectorAll('.animate');
    
    if (animatedElements.length > 0) {
        window.addEventListener('scroll', function() {
            for (let i = 0; i < animatedElements.length; i++) {
                const element = animatedElements[i];
                const elementPosition = element.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (elementPosition < windowHeight - 50) {
                    element.classList.add('animated');
                }
            }
        });
    }
}); 